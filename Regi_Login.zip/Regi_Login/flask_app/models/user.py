from flask_app.config.mysqlconnection import connectToMySQL
from flask import Flask, render_template, request, redirect, flash
import re
from flask_bcrypt import Bcrypt  

class User:
    def __init__( self , data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.password = data['password']
        self.created_at = data['created_at']
    @classmethod
    def save(cls, data ):
        query = "INSERT INTO user ( first_name, last_name, email, password) VALUES ( %(first_name)s, %(last_name)s, %(email)s, %(password)s);"
        # data is a dictionary that will be passed into the save method from server.py
        return connectToMySQL('regilogin').query_db( query, data )

    @staticmethod
    def verf_email_original(data):
        query = "SELECT * FROM user WHERE email = %(email)s;"
        verf = False
        # data is a dictionary that will be passed into the save method from server.py
        x = connectToMySQL('regilogin').query_db( query, data )
        try:
            if len(x) > 0:
                verf = True
        except TypeError:
            return verf
        return verf

    @classmethod
    def get_by_email(cls,data):
        query = "SELECT * FROM user WHERE email = %(email)s;"
        result = connectToMySQL("regilogin").query_db(query,data)
        # Didn't find a matching user
        if len(result) < 1:
            return False
        return cls(result[0])
    @staticmethod
    def validate_creds(data):
        validate = True
        if len(data['first_name']) < 2:
            validate = False
            flash('First Name needs to be greater than 2 characters', 'first_name')
        if data['first_name'] == '':
            validate = False
            flash('First Name needs to be submitted', 'first_name')
        if not data['first_name'].isalpha():
            validate = False
            flash('First Name needs to be only alphabet characters', 'first_name')
        if len(data['last_name']) < 2:
            validate = False
            flash('Last Name needs to be greater than 2 characters', 'last_name')
        if data['last_name'] == '':
            validate = False
            flash('Last Name needs to be submitted', 'last_name')
        if not data['last_name'].isalpha():
            validate = False
            flash('Last Name needs to be only alphabet characters', 'last_name')
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 
        if not EMAIL_REGEX.match(data['email']): 
            flash("Invalid email address!", 'email')
            validate = False
        if data['password'] != data['conf_password']:
            validate = False
            flash('passwords not matching', 'password')
        if len(data['password']) < 8:
            validate = False
            flash('password needs to be greater than 8 characters', 'password')
        if User.verf_email_original(data['email']):
            validate = False
            flash('email is aready used', 'email')
        return validate